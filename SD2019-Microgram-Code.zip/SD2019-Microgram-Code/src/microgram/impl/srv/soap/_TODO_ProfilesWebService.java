package microgram.impl.srv.soap;


import java.util.List;
import java.util.Set;

import microgram.api.Profile;
import microgram.api.java.Profiles;
import microgram.api.soap.MicrogramException;
import microgram.api.soap.SoapProfiles;
import microgram.impl.srv.java.JavaProfiles;

//Make this class concrete.
public class _TODO_ProfilesWebService extends SoapService implements SoapProfiles {

	final Profiles impl;
	
	protected _TODO_ProfilesWebService() {
		this.impl = new JavaProfiles();
	}
	
	@Override
	public Profile getProfile( String userId ) throws MicrogramException {
		return super.resultOrThrow( impl.getProfile(userId));
	}
	
	public void createProfile(Profile profile) throws MicrogramException
	{
		super.resultOrThrow(impl.createProfile(profile));
	}
	
	public void deleteProfile(String userId) throws MicrogramException
	{
		super.resultOrThrow(impl.deleteProfile(userId));
	}
	
	public void follow(String userId1, String userId2, boolean isFollowing) throws MicrogramException
	{
		super.resultOrThrow(impl.follow(userId1, userId2, isFollowing));
	}
	
	public boolean isFollowing(String userId1, String userId2) throws MicrogramException
	{
		return super.resultOrThrow(impl.isFollowing(userId1, userId2));
	}
	
	public List<Profile> search(String name) throws MicrogramException
	{
		return super.resultOrThrow(impl.search(name));
	}	
	
	public List<String> getUsersFollowing(String userId) throws MicrogramException
	{
		return super.resultOrThrow(impl.getFollowingUsers(userId));
	}
	
}
