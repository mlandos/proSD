package microgram.impl.srv.java;

import static microgram.api.java.Result.error;
import static microgram.api.java.Result.ok;
import static microgram.api.java.Result.ErrorCode.CONFLICT;
import static microgram.api.java.Result.ErrorCode.NOT_FOUND;
import static microgram.api.java.Result.ErrorCode.NOT_IMPLEMENTED;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Logger;

import discovery.Discovery;
import kafka.KafkaPublisher;
import microgram.api.Post;
import microgram.api.Profile;
import microgram.api.java.Posts;
import microgram.api.java.Profiles;
import microgram.api.java.Result;
import microgram.impl.clt.rest._TODO_RestProfilesClient;
import microgram.impl.srv.java.JavaProfiles;
import microgram.impl.srv.rest.ProfilesRestServer;
import utils.Hash;
import microgram.impl.clt.java.RetryClient;
import microgram.impl.clt.rest.*;
import kafka.KafkaPublisher;
import kafka.KafkaSubscriber;
import kafka.KafkaUtils;


//DIOGO GATO - 20190502 0300 - ALL CLASS CHANGED
public class JavaPosts implements Posts
{

	private static Logger Log = Logger.getLogger(Discovery.class.getName());
	
	public static final String POSTS_EVENTS = "Microgram-PostsEvents";
	
	protected ConcurrentMap<String, Post> posts = new ConcurrentHashMap<>();
	protected ConcurrentMap<String, Set<String>> likes = new ConcurrentHashMap<>();
	protected ConcurrentMap<String, Set<String>> userPosts = new ConcurrentHashMap<>();

	//enum PostsEventKeys { DELETE, CREATE, LIKE };
	//List<String> PostsTopicsSub; //TOPICS TO SUBSCRIBE
	
	//final KafkaPublisher kafkaPub;
	//final KafkaSubscriber kafkaSub;
	
	public JavaPosts()
	{
		//this.kafkaPub = new KafkaPublisher();
		//PostsTopicsSub = Arrays.asList(JavaProfiles.PROFILES_EVENTS);
		//this.kafkaSub = new KafkaSubscriber(PostsTopicsSub);
	}
	
	@Override
	public Result<Post> getPost(String postId)
	{
		Post res = posts.get(postId);
		if (res != null)
			return ok(res);
		else
			return error(NOT_FOUND);
	}

	@Override
	public Result<Void> deletePost(String postId)
	{
		Post thisPost = posts.get(postId);
		if(thisPost == null)
			return error(NOT_FOUND);
		posts.remove(postId);
		likes.remove(postId);
		userPosts.get(thisPost.getOwnerId()).remove(postId);
		
		//kafkaPub.publish(POSTS_EVENTS, PostsEventKeys.DELETE.name(), postId);
		
		return ok();
	}

	@Override
	public Result<String> createPost(Post post)
	{
		String postId = Hash.of(post.getOwnerId(), post.getMediaUrl());
		if (posts.putIfAbsent(postId, post) == null)
		{

			likes.put(postId, ConcurrentHashMap.newKeySet());

			Set<String> posts = userPosts.get(post.getOwnerId());
			if (posts == null)
				userPosts.put(post.getOwnerId(), posts = ConcurrentHashMap.newKeySet());

			posts.add(postId);
		}
		
		//kafkaPub.publish(POSTS_EVENTS, PostsEventKeys.CREATE.name(), postId);
		return ok(postId);
	}

	@Override
	public Result<Void> like(String postId, String userId, boolean isLiked)
	{

		Set<String> res = likes.get(postId);
		if (res == null)
			return error(NOT_FOUND);

		if (isLiked) {
			if (!res.add(userId))
				return error(CONFLICT);
		} else {
			if (!res.remove(userId))
				return error(NOT_FOUND);
		}

		getPost(postId).value().setLikes(res.size());
		
		//kafkaPub.publish(POSTS_EVENTS, PostsEventKeys.LIKE.name(), postId);
		
		return ok();
	}

	@Override
	public Result<Boolean> isLiked(String postId, String userId)
	{
		Set<String> res = likes.get(postId);

		if (res != null)
			return ok(res.contains(userId));
		else
			return error(NOT_FOUND);
	}

	@Override
	public Result<List<String>> getPosts(String userId)
	{
		Set<String> res = userPosts.get(userId);
		if (res != null)
			return ok(new ArrayList<>(res));
		else
			return error(NOT_FOUND);
	}

	@Override
	public Result<List<String>> getFeed(String userId)
	{
		URI[] profilesUri = Discovery.findUrisOf(ProfilesRestServer.SERVICE, 1);
		_TODO_RestProfilesClient profilesClient = new _TODO_RestProfilesClient(profilesUri[0]);
		Result<List<String>> followingUsers = profilesClient.getFollowingUsers(userId);
		
		List<String> posts = new ArrayList<String>();
		//GET THE FEED FROM HIMSELF AND FOLLOWING USERS
		List<String> usersPosts = followingUsers.value();

		if (usersPosts==null)
		{
			return error(NOT_FOUND);
		}
		for (String user : usersPosts)
			posts.addAll(userPosts.get(user));
		
		posts.addAll(userPosts.get(userId)); //Own User posts
		
		return ok(posts);
	}
	
	
}
