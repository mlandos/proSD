package microgram.impl.srv.rest;


import java.net.URI;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import javax.ws.rs.core.MediaType;

import discovery.Discovery;
import microgram.api.Profile;
import microgram.api.java.Profiles;
import microgram.api.rest.RestProfiles;
import microgram.impl.srv.java.JavaProfiles;


public class RestProfilesResources extends RestResource implements RestProfiles
{
	private static Logger Log = Logger.getLogger(RestResource.class.getName());
	
	final Profiles impl;
	final String baseURI;
	
	//DIOGO GATO 20190427 0230
	public RestProfilesResources(URI serverUri)
	{
		this.impl = new JavaProfiles();
		this.baseURI = serverUri.toString() + RestProfiles.PATH;
	}
	
	@Override
	public Profile getProfile(String userId)
	{
		return super.resultOrThrow( impl.getProfile(userId));
	}

	@Override
	//DONE - DIOGO GATO 20190427 0230
	public void createProfile(Profile profile)
	{
		super.resultOrThrow(impl.createProfile(profile));
	}
	
	//DIOGO GATO 20190427 1830
	public void deleteProfile(String userId)
	{
		super.resultOrThrow(impl.deleteProfile(userId));
	}

	@Override
	//DONE - DIOGO GATO 20190427 0230
	public void follow(String userId1, String userId2, boolean isFollowing)
	{
		super.resultOrThrow(impl.follow(userId1, userId2, isFollowing));
	}

	@Override
	//DONE - DIOGO GATO 20190427 0230
	public boolean isFollowing(String userId1, String userId2)
	{
		return super.resultOrThrow(impl.isFollowing(userId1, userId2));
	}

	@Override
	//DONE - DIOGO GATO 20190427 0230
	public List<Profile> search(String name)
	{
		return super.resultOrThrow(impl.search(name));
	}	
	
	//DIOGO GATO - 20190502 1500
	public List<String> getFollowingUsers(String userId)
	{
		return super.resultOrThrow(impl.getFollowingUsers(userId));
	}
	
}
