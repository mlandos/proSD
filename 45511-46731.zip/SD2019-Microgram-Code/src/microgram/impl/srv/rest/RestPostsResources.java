package microgram.impl.srv.rest;

import java.net.URI;
import java.util.List;

import microgram.api.Post;
import microgram.api.java.Posts;
import microgram.api.rest.RestPosts;
import microgram.api.rest.RestProfiles;
import microgram.impl.srv.java.JavaPosts;


public class RestPostsResources extends RestResource implements RestPosts {

	final Posts impl;
	final String baseURI;
		
	public RestPostsResources(URI serverUri) {
		this.impl = new JavaPosts();
		this.baseURI = serverUri.toString() + RestProfiles.PATH;
	}
	
	@Override
	public Post getPost(String postId) {
		return super.resultOrThrow(impl.getPost(postId));
	}

	@Override
	public String createPost(Post arg0) {
		return super.resultOrThrow(impl.createPost(arg0));
	}

	@Override
	public void deletePost(String arg0) {
		super.resultOrThrow(impl.deletePost(arg0));		
	}

	@Override
	public List<String> getFeed(String arg0) {
		return super.resultOrThrow(impl.getFeed(arg0));
	}

	@Override
	public List<String> getPosts(String arg0) {
		return super.resultOrThrow(impl.getPosts(arg0));
	}

	@Override
	public boolean isLiked(String arg0, String arg1) {
		return super.resultOrThrow(impl.isLiked(arg0, arg1));
	}

	@Override
	public void like(String arg0, String arg1, boolean arg2) {
		super.resultOrThrow(impl.like(arg0, arg1, arg2));
		
	}
 
}
