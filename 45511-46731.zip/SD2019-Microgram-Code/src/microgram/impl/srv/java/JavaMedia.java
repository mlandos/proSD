package microgram.impl.srv.java;

import static microgram.api.java.Result.error;
import static microgram.api.java.Result.ErrorCode.CONFLICT;
import static microgram.api.java.Result.ErrorCode.INTERNAL_ERROR;
import static microgram.api.java.Result.ErrorCode.NOT_FOUND;

import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Random;

import microgram.api.java.Media;
import microgram.api.java.Result;
import utils.Hash;

import kafka.KafkaPublisher;
import kafka.KafkaSubscriber;
import kafka.KafkaUtils;

//DIOGO GATO - 20190502 0300 - ALL CLASS CHANGED
public class JavaMedia implements Media
{
	private static final String MEDIA_EXTENSION = ".jpg";
	private static final String ROOT_DIR = "/tmp/microgram/";
	public static final String MEDIA_STORAGE_EVENTS = "Microgram-MediaStorageEvents";
	
	//enum MediaEventKeys { UPLOAD, DOWNLOAD, DELETE };

	static final Random random = new Random();
	
	//final KafkaPublisher kafka;
	
	public JavaMedia()
	{
		new File(ROOT_DIR).mkdirs();
		
		//this.kafka = new KafkaPublisher();
		
		//KafkaUtils.createTopics(Arrays.asList(JavaMedia.MEDIA_STORAGE_EVENTS));
	}

	@Override
	public Result<String> upload(byte[] bytes)
	{
		try
		{
			String id = Hash.of(bytes);
			File filename = new File(ROOT_DIR + id + MEDIA_EXTENSION);

			if (filename.exists())
				return Result.error(CONFLICT);

			Files.write(filename.toPath(), bytes);
			
			//Kafka
			//kafka.publish(MEDIA_STORAGE_EVENTS, MediaEventKeys.UPLOAD.name(), id);
			
			return Result.ok(id);
		}
		catch (Exception x)
		{
			return error(INTERNAL_ERROR);
		}
	}

	@Override
	public Result<byte[]> download(String id)
	{
		try
		{
			File filename = new File(ROOT_DIR + id + MEDIA_EXTENSION);

			if (filename.exists())
			{
				//kafka.publish(MEDIA_STORAGE_EVENTS, MediaEventKeys.DOWNLOAD.name(), id);
				return Result.ok(Files.readAllBytes(filename.toPath()));
			}
			else
				return Result.error(NOT_FOUND);
		}
		catch (Exception x)
		{
			return Result.error(INTERNAL_ERROR);
		}
	}
	
	@Override
	public Result<Void> delete(String id)
	{
		try
		{
			File filename = new File(ROOT_DIR + id + MEDIA_EXTENSION);
			if (filename.exists())
			{
				if (filename.delete())
				{
					//kafka.publish(MEDIA_STORAGE_EVENTS, MediaEventKeys.DELETE.name(), id);
					return Result.ok();
				}
				else
					return Result.error(INTERNAL_ERROR);
			}
			else
				return Result.error(NOT_FOUND);
						
		}
		catch (Exception x)
		{
			return Result.error(INTERNAL_ERROR);
		}
	}
}
