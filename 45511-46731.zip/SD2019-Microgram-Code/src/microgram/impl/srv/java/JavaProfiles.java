package microgram.impl.srv.java;

import static microgram.api.java.Result.error;
import static microgram.api.java.Result.ok;
import static microgram.api.java.Result.ErrorCode.CONFLICT;
import static microgram.api.java.Result.ErrorCode.NOT_FOUND;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

import discovery.Discovery;
import microgram.api.Profile;
import microgram.api.java.Result;
import microgram.api.java.Result.ErrorCode;
import microgram.impl.clt.rest.RestPostsClient;
import microgram.impl.clt.rest.RestProfilesClient;
import microgram.impl.srv.rest.PostsRestServer;
import microgram.impl.srv.rest.ProfilesRestServer;
import microgram.impl.srv.rest.RestResource;

import kafka.KafkaPublisher;
import kafka.KafkaSubscriber;
import kafka.KafkaUtils;

//DIOGO GATO - 20190502 0300 - ALL CLASS CHANGED
public class JavaProfiles extends RestResource implements microgram.api.java.Profiles
{

	protected ConcurrentMap<String, Profile> users = new ConcurrentHashMap<>();
	protected ConcurrentMap<String, Set<String>> followers = new ConcurrentHashMap<>();
	protected ConcurrentMap<String, Set<String>> following = new ConcurrentHashMap<>();
	
	public static final String PROFILES_EVENTS = "Microgram-ProfilesEvents";
	
	//enum ProfilesEventKeys { CREATE, DELETE, FOLLOW_USER, NEW_FOLLOW}
	//List<String> ProfilesTopicsSub; //TOPICS TO SUBSCRIBE
	
	//final KafkaPublisher kafkaPub;
	//final KafkaSubscriber kafkaSub;
	
	public JavaProfiles()
	{
		//this.kafkaPub = new KafkaPublisher();
		//ProfilesTopicsSub = Arrays.asList(JavaPosts.POSTS_EVENTS);
		//this.kafkaSub = new KafkaSubscriber(ProfilesTopicsSub);
	}
	
	@Override
	public Result<Profile> getProfile(String userId)
	{
		Profile res = users.get( userId );
		if( res == null ) 
			return error(NOT_FOUND);

		res.setFollowers( followers.get(userId).size() );
		res.setFollowing( following.get(userId).size() );
		Result<List<String>> aux = getPostsSize(userId);
		if(aux.isOK())
			res.setPosts(aux.value().size() );
		else
			res.setPosts(0);
		return ok(res);
	}
	
	private Result<List<String>> getPostsSize(String userId) {
		URI[] postsUri = Discovery.findUrisOf(PostsRestServer.SERVICE, 1);
		RestPostsClient postsClient = new RestPostsClient(postsUri[0]);
		
		return postsClient.getPosts(userId);
	}

	@Override
	public Result<Void> createProfile(Profile profile)
	{
		Profile res = users.putIfAbsent( profile.getUserId(), profile );
		if( res != null ) 
			return error(CONFLICT);
		
		followers.put( profile.getUserId(), ConcurrentHashMap.newKeySet());
		following.put( profile.getUserId(), ConcurrentHashMap.newKeySet());
		
		//kafkaPub.publish(PROFILES_EVENTS, ProfilesEventKeys.CREATE.name(), profile.getUserId());
		
		return ok();
	}
	
	@Override
	//DONE - DIOGO GATO: 20190427 18:30
	public Result<Void> deleteProfile(String userId)
	{
		Profile del = users.remove(userId);
		
		if (del == null)
			return error(NOT_FOUND);

		for(String follower: followers.get(userId))
		{
			following.get(follower).remove(userId);
		}
		for(String following : following.get(userId))
		{
			followers.get(following).remove(userId);
		}
		
		followers.remove(userId);
		following.remove(userId);
		
		//kafkaPub.publish(PROFILES_EVENTS, ProfilesEventKeys.CREATE.name(), userId);
		
		return ok();
	}
	
	@Override
	public Result<List<Profile>> search(String prefix) {
		return ok(users.values().stream()
				.filter( p -> p.getUserId().startsWith( prefix ) )
				.collect( Collectors.toList()));
	}

	@Override
	public Result<Void> follow(String userId1, String userId2, boolean isFollowing)
	{		
		Set<String> s1 = following.get( userId1 );
		Set<String> s2 = followers.get( userId2 );
		
		if( s1 == null || s2 == null)
			return error(NOT_FOUND);
		
		if( isFollowing ) {
			boolean added1 = s1.add(userId2 ), added2 = s2.add( userId1 );
			if( ! added1 || ! added2 )
				return error(CONFLICT);		
		} else {
			boolean removed1 = s1.remove(userId2), removed2 = s2.remove( userId1);
			if( ! removed1 || ! removed2 )
				return error(NOT_FOUND);					
		}
		
		//kafkaPub.publish(PROFILES_EVENTS, ProfilesEventKeys.FOLLOW_USER.name(), userId1);
		//kafkaPub.publish(PROFILES_EVENTS, ProfilesEventKeys.NEW_FOLLOW.name(), userId2);
		
		return ok();
	}

	@Override
	public Result<Boolean> isFollowing(String userId1, String userId2)
	{

		Set<String> s1 = following.get( userId1 );
		Set<String> s2 = followers.get( userId2 );
		
		if( s1 == null || s2 == null)
			return error(NOT_FOUND);
		else
			return ok(s1.contains( userId2 ) && s2.contains( userId1 ));
	}

	@Override
	public Result<List<String>> getFollowingUsers(String userId)
	{
		Set<String> s = following.get( userId );
		
		if( s == null)
			return error(NOT_FOUND);
		else
		{
			return ok(new ArrayList<String>(s));
		}
			
	}
	
}
