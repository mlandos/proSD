package microgram.impl.srv.soap;

import java.util.List;

import javax.jws.WebService;

import microgram.api.Post;
import microgram.api.java.Posts;
import microgram.api.soap.MicrogramException;
import microgram.api.soap.SoapPosts;
import microgram.impl.srv.java.JavaPosts;

@WebService(serviceName=SoapPosts.NAME,targetNamespace=SoapPosts.NAMESPACE, endpointInterface=SoapPosts.INTERFACE)
public class PostsWebService extends SoapService implements SoapPosts {

	final Posts impl;
	
	protected PostsWebService() {
		this.impl = new JavaPosts();
	}

	@Override
	public Post getPost( String postId ) throws MicrogramException {
		return super.resultOrThrow( impl.getPost(postId));
	}
	
	@Override
	public String createPost( Post postId ) throws MicrogramException {
		return super.resultOrThrow( impl.createPost(postId));
	}
	
	@Override
	public void deletePost( String postId ) throws MicrogramException{
		super.resultOrThrow( impl.deletePost(postId));
	}
	
	@Override
	public List<String> getPosts(String arg0) throws MicrogramException{
		return super.resultOrThrow(impl.getPosts(arg0));
	}
	
	@Override
	public boolean isLiked(String arg0, String arg1) throws MicrogramException{
		return super.resultOrThrow(impl.isLiked(arg0, arg1));
	}
	
	@Override
	public void like(String arg0, String arg1, boolean arg2) throws MicrogramException {
		super.resultOrThrow(impl.like(arg0, arg1, arg2));	
	}

	@Override
	public List<String> getFeed(String userId) throws MicrogramException {
		return super.resultOrThrow(impl.getFeed(userId));	
	}
}
