package microgram.impl.clt.soap;

import java.net.URI;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import discovery.Discovery;
import microgram.api.java.Media;
import microgram.api.java.Result;
import microgram.api.soap.SoapMedia;
import microgram.api.soap.SoapPosts;
import microgram.impl.srv.soap.PostsSoapServer;

public class SoapMediaClient extends SoapClient implements Media {
	static final QName QNAME = new QName(SoapMedia.NAMESPACE, SoapMedia.NAME);

	SoapMedia impl;
	private static final String WSDL = "?wsdl";

	public SoapMediaClient(URI uri) {
		super(uri);
	}

	@Override
	public Result<String> upload(byte[] bytes) {
		return super.tryCatchResult(() -> impl.upload(bytes));
	}

	@Override
	public Result<byte[]> download(String id) {
		return super.tryCatchResult(() -> impl.download(id));
	}

	@Override
	public Result<Void> delete(String id) {
		return super.tryCatchVoid(() -> impl.delete(id));
	}
	
	private SoapMedia impl() {
		if( impl == null ) {
			QName QNAME = new QName(SoapPosts.NAMESPACE, SoapPosts.NAME);
			try {
//				Discovery.findUrisOf(PostsSoapServer.SERVICE, 1)[0]
				Service service = Service.create(new URL(this.uri + WSDL), QNAME);
				impl = service.getPort( microgram.api.soap.SoapMedia.class);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		return impl;
	}

}
