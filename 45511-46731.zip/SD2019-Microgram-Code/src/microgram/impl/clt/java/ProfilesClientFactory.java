package microgram.impl.clt.java;

import java.net.URI;

import microgram.impl.clt.rest.RestMediaClient;
import microgram.impl.clt.rest.RestPostsClient;
import microgram.impl.clt.rest.RestProfilesClient;
import microgram.impl.clt.soap.SoapMediaClient;
import microgram.impl.clt.soap.SoapPostsClient;
import microgram.impl.clt.soap.SoapProfilesClient;
import microgram.api.java.Media;
import microgram.api.java.Posts;
import microgram.api.java.Profiles;

public class ProfilesClientFactory {

	private static final String REST = "/rest";
	private static final String SOAP = "/soap";

	public static Profiles getMediaClient(URI uri) {
		String uriString = uri.toString();
		if (uriString.endsWith(REST))
			return new RestProfilesClient(uri);
		else if (uriString.endsWith(SOAP))
			return new SoapProfilesClient(uri);

		throw new RuntimeException("Unknown service type..." + uri);
	}
}
