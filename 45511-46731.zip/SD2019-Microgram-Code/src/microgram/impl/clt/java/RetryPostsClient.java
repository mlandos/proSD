package microgram.impl.clt.java;

import java.util.List;

import microgram.api.Post;
import microgram.api.java.Posts;
import microgram.api.java.Result;

public class RetryPostsClient extends RetryClient implements Posts {

	final Posts impl;
	
	public RetryPostsClient( Posts impl ) {
		this.impl = impl;
	}

	@Override
	public Result<Post> getPost(String postId) {
		return reTry( () -> impl.getPost(postId));
	}

	@Override
	public Result<String> createPost(Post arg0) {
		// TODO Auto-generated method stub
		return reTry( () -> impl.createPost(arg0));
	}

	@Override
	public Result<Void> deletePost(String arg0) {
		return reTry( () -> impl.deletePost(arg0));
	}

	@Override
	public Result<List<String>> getFeed(String arg0) {
		return reTry( () -> impl.getFeed(arg0));
	}

	@Override
	public Result<List<String>> getPosts(String arg0) {
		return reTry( () -> impl.getPosts(arg0));
	}

	@Override
	public Result<Boolean> isLiked(String arg0, String arg1) {
		return reTry( () -> impl.isLiked(arg0, arg1));
	}

	@Override
	public Result<Void> like(String arg0, String arg1, boolean arg2) {
		return reTry( () -> impl.like(arg0, arg1, arg2));
	}

}
