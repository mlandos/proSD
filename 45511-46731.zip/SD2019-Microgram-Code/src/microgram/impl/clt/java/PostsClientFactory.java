package microgram.impl.clt.java;

import java.net.URI;

import microgram.impl.clt.rest.RestMediaClient;
import microgram.impl.clt.rest.RestPostsClient;
import microgram.impl.clt.soap.SoapMediaClient;
import microgram.impl.clt.soap.SoapPostsClient;
import microgram.api.java.Media;
import microgram.api.java.Posts;

public class PostsClientFactory {

	private static final String REST = "/rest";
	private static final String SOAP = "/soap";

	public static Posts getMediaClient(URI uri) {
		String uriString = uri.toString();
		if (uriString.endsWith(REST))
			return new RestPostsClient(uri);
		else if (uriString.endsWith(SOAP))
			return new SoapPostsClient(uri);

		throw new RuntimeException("Unknown service type..." + uri);
	}
}
