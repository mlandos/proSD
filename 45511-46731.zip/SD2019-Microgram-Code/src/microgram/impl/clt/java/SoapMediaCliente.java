package microgram.impl.clt.java;

public class SoapMediaCliente {

}
