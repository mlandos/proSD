package microgram.impl.clt.rest;

import java.net.URI;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import microgram.api.Profile;
import microgram.api.java.Media;
import microgram.api.java.Media;
import microgram.api.java.Result;
import microgram.api.rest.RestMediaStorage;

public class RestMediaClient extends RestClient implements Media {

	public RestMediaClient(URI mediaStorage) {
		super(mediaStorage, RestMediaStorage.PATH);
	}

	public Result<String> upload(byte[] bytes) 
	{
		return super.reTry(() -> _upload_v2(bytes));
	}

	public Result<byte[]> download(String url)
	{
		Response r = target.path(url)
				   		   .request()
				   		   .get();

		return super.responseContents(r, Status.OK, new GenericType<byte[]>() {});
	}

	Result<String> _upload_v2(byte[] bytes)
	{
		Response r = super.target.request().accept(MediaType.APPLICATION_JSON)
								.post(Entity.entity(bytes, MediaType.APPLICATION_OCTET_STREAM));

		return super.responseContents(r, Status.OK, new GenericType<String>() {
		});
	}

	@Override
	public Result<Void> delete(String id)
	{
		Response r = target.path(id)
				   		   .request()
				   		   .delete();

		return super.verifyResponse(r, Status.NO_CONTENT);
	}
}